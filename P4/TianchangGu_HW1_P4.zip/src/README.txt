This project is written by Tianchang Gu for the course project Dynamic Programming in Tic-Tac-Toe

###steps to run TTT###
1. change direction to current path and run
	python main.py dummy.txt output_ttt.txt

###usage main.py###
usage: main.py [-h] input_file output_file

positional arguments:
  input_file           name for the input file.
  output_file           name for the output file.

###special library requirements###
numpy, argparse
python2.7

###folder contents###
There are one library for the cleaness of the code.
	TicTacToe.py

There are one main script for TTT.
	main.py
