This project is written by Tianchang Gu for the course project Dynamic Programming in Path Planning

###steps to run PP###
1. change direction to current path and run
	python main.py data/input1.txt data/output_dsp.txt

###usage main.py###
usage: main.py [-h] input_file output_file

positional arguments:
  input_file   name of the input file.
  output_file  name for the output file.

###special library requirements###
numpy, argparse
python2.7

###folder contents###
There are one library for the cleaness of the code.
	PathPlanning.py

There are one main script for TTT.
	main.py

